from django.contrib import admin

from .models import Filling, Pizza, Order, Seller

admin.site.register(Filling)
#admin.site.register(Pizza)
#admin.site.register(Order)
admin.site.register(Seller)

class PizzaAdmin(admin.ModelAdmin):
    list_display = ('title', 'dough', 'sauce', 'display_filling','price')


# Register the admin class with the associated model
admin.site.register(Pizza, PizzaAdmin)


class OrderAdmin(admin.ModelAdmin):
    list_display = ('number', 'display_pizza', 'due_back', 'status')
    list_filter = ('status', 'due_back')

# Register the admin class with the associated model
admin.site.register(Order, OrderAdmin)