from django.shortcuts import render
from django.views import generic
from .models import Pizza, Order, Seller

def index(request):

    num_pizzas = Pizza.objects.all().count()
    num_orders = Order.objects.all().count()
   # num_instance_available = BookInstance.objects.filter(status__exact='a').count()
   # num_authors = Author.objects.count()

    num_visits = request.session.get('num_visits', 0)
    request.session['num_visits'] = num_visits + 1

    return render(
        request,
        'index.html',
        context={'num_pizzas':num_pizzas, 'num_orders':num_orders,
                 'num_visits':num_visits}
    )

def test_view(request):
    return render(request, 'base_generic.html', {})


class PizzaListView(generic.ListView):
    model = Pizza

class PizzaDetailView(generic.DetailView):
    model = Pizza

class OrderListView(generic.ListView):
    model = Order
    paginate_by = 5

class OrderDetailView(generic.DetailView):
    model = Order
