from django.db import models
from django.contrib.auth.models import User
from datetime import date

class Filling(models.Model):
    name = models.CharField(max_length=200, help_text="Enter an ingredient")
    def __str__(self):
        return self.name

from django.urls import reverse

class Pizza(models.Model):
    title = models.CharField(max_length=200)
    dough = models.CharField('Dough', max_length=200)
    sauce = models.CharField(max_length=200, help_text="Enter a sauce")
    filling = models.ManyToManyField('Filling', help_text="Select an ingredient for this pizza")
    price = models.IntegerField('Price')

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('pizza-detail', args=[str(self.id)])

    def display_filling(self):
        return ', '.join([filling.name for filling in self.filling.all()[:3]])

    display_filling.short_description = 'Filling'



class Order(models.Model):

    number = models.AutoField(primary_key=True, blank=True, help_text="Number of order")
    pizza = models.ManyToManyField('Pizza', help_text="Select list of pizza's")
    amount = models.IntegerField('Amount', default=1)
    due_back = models.DateTimeField(null=True, blank=True, auto_now_add=True, verbose_name='Дата и время заказа')

    #class Meta:
     #   ordering = ["due_back"]

    ORDER_STATUS = (
        ('created', 'Created'),
        ('prepare', 'Prepared'),
        ('ready', 'Ready'),
    )

    status = models.CharField(max_length=100, choices=ORDER_STATUS, blank=True, default='new',
                              help_text='Статус заказа')


    def __str__(self):
        return '%s (%s)' % (self.number, self.pizza)

    def get_absolute_url(self):
        return reverse('order-detail', args=[str(self.number)])

    def display_pizza(self):
        return ', '.join([pizza.title for pizza in self.pizza.all()[:3]])

    def summ_check(self):
        total = 0
        for pizza in self.pizza.all():
            total += pizza.price * self.amount
        return total


class Seller(models.Model):
    first_name = models.CharField(max_length=200)
    last_name = models.CharField(max_length=200)
    open_time = models.DateTimeField(null=True, blank=True, auto_now_add=True, db_index=True)
    close_time = models.DateTimeField('Close', null=True, blank=True, db_index=True)

    def __str__(self):
        return '%s (%s)' % (self.last_name, self.first_name)
