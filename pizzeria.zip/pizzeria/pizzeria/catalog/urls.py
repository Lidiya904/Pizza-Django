from django.urls import path
from . import views


urlpatterns = [
    path('', views.test_view, name='index'),
    path('pizzas/', views.PizzaListView.as_view(), name='pizzas'),
    path('pizza/<int:pk>', views.PizzaDetailView.as_view(), name='pizza-detail'),
    path('orders/', views.OrderListView.as_view(), name='orders'),
    path('order/<int:pk>', views.OrderDetailView.as_view(), name='order-detail'),
]
