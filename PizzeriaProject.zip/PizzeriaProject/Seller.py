import Zakaz
import datetime
import main
import Pizza
import time

class Seller:

    def __init__(self, FIO):
        self.FIO = FIO
        self.time_open = None
        self.time_close = None

    # время открытия чека
    def timeOpen(self):
        self.time_open = datetime.datetime.now()
        return self.time_open

    # время закрытия чека
    def timeClose(self):
        self.time_close = datetime.datetime.now()
        return self.time_close

    def print_check(self, bar, pep, sea, term):

        print("ЧЕК ЗАКРЫТИЯ ДНЯ")
        print("*" * 40)
        print("Кассир: ", self.FIO)

        print("общий список проданных позиций")
        if bar.count != 0:
            print(bar.title, "\t\t * ", bar.count, " = ",
                  bar.price * bar.count)

        if pep.count != 0:
            print(pep.title, "\t\t * ", pep.count, " = ",
                  pep.price * pep.count)

        if sea.count != 0:
            print(sea.title, "\t\t * ", sea.count, " = ",
                  sea.price * sea.count)
        print("общая выручка", bar.count * bar.price + pep.count * pep.price + sea.count * sea.price)
        print("сумма наличных в кассе: ", term.cash)
        print("оплата по карте: ", term.card_payment)
        print("*" * 40)

